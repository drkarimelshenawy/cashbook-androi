// Apply in a host with Kotlin 2.x + Compose plugin already versioned in its root.
// For Kotlin 1.x hosts, adapt to that host's existing Compose compiler configuration.
plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.todoshift.cashbook"
    compileSdk = 35
    buildToolsVersion = "35.0.0"
    defaultConfig { minSdk = 26 }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
}
dependencies {
    implementation(project(":cashbook-core"))
    // Host must supply its existing Compose BOM and aligned AndroidX versions.
    implementation(platform(providers.gradleProperty("cashbook.composeBom").get()))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:" + providers.gradleProperty("cashbook.activityVersion").get())
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:" + providers.gradleProperty("cashbook.lifecycleVersion").get())
    implementation("androidx.lifecycle:lifecycle-runtime-compose:" + providers.gradleProperty("cashbook.lifecycleVersion").get())
}
