# Release 0.12 verification

12 November 2026. Test package: com.todoshift.cashbook.sandbox, version 0.12.0-test (8).

## Build and core

Gradle 8.9 / AGP 8.7.3 / Kotlin 2.0.21, compile/target 35, min 26. Debug application and instrumentation APKs build successfully. Android Lint reports zero errors and two dependency-update advisories for the deliberately pinned Activity 1.9.3 dependencies. No dependency upgrade is included in this feature release. APK v2 signature is verified and the certificate matches 0.11, allowing an in-place update.

428 core assertions pass, including 67 new checks for whole-unit input, Arabic/Persian digits, overflow and rejected decimals, exact legacy fractional values, optional account linking, atomic link/unlink edits, targeted installment payments, early credit, duplicate detection, soft delete/undo, storage rollback, schema 6 migration, and schema 7 backup restore twice without duplicates. The earlier account order, generic account presets and icon tests remain included.

Resource validation passes for 295 matched English/Arabic keys and format parameters. Kotlin UI contains no fixed Arabic prose. User names and notes remain unchanged.

## Native execution

API 26 x86 software emulator, 540×1170 at density 240. The upgrade test installs the real 0.11 APK, seeds a schema-6 fixture, and installs 0.12 over it without clearing application data. Exact financial-file bytes match before the first new save.

All four Release12FlowTest scenarios pass on the final application build: paymentsAndLegacy (86.059s), languageDraftKeyboard (70.924s), backupAndReminders (80.188s), and restartAndSmallScreen (64.539s, repeated with a real input tap and explicit IME visibility check). The emulator was cold-restarted between the language and reminder scenarios; the saved two-debt baseline was recovered from the isolated restore fixture before resuming. Raw reports and screenshots are in verification/. The fixture is synthetic and included as legacy-v6.cbk. It contains a principal of 300.50, an old payment of 50.50 and a financial account opening of 123.45. The final calculated 0.50 debt remainder is paid exactly, without rounding or manually enabling decimal input.

Language verification compares the same open draft and financial bytes before/after switching Arabic to English. It also checks fixed Save-button coordinates, the English native date dialog, the actual language settings, native numeric/signed input types, and rendering with the keyboard open. Backup validation restores twice into a separate AndroidLedgerStore. Reminder validation checks actual Arabic/English Android notifications, stable post times on reload and cancellation after full payment. A new process reads the saved balances and early-credit metadata. Small-screen verification uses 480×960 pixels (320dp) and font scale 1.15 in both languages.

## Limits

Execution is on an API-26 emulator, not a physical device or every Android version. The software emulator's Launcher had an unrelated ANR; it was stopped before clean screenshots were reviewed. Instrumentation-selector fixes were confined to the test harness. An IME overlap discovered during QA was corrected by making the debt dialogs resize with the keyboard before the final native run. The financial workflows run against the native app, not an HTML preview.

External file pickers and the keyboard application's own language follow Android system settings. App-created date/time dialogs use the selected section language. New amounts accept whole units; old fractional values retain exact precision, and an exact computed final payoff is available. Schema 7 reads schemas 1–6; old releases cannot read a schema-7 file after a new save. Backups are not encrypted. No ToDo Shift source or installed application was modified or merged. The module retains its host/reminder integration boundaries.
