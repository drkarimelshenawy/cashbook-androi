from pathlib import Path
import xml.etree.ElementTree as E,re
root=Path(__file__).resolve().parents[1];res=root/'cashbook-feature/src/main/res'
def read(folder):return {x.attrib['name']:''.join(x.itertext()) for x in E.parse(res/folder/'strings.xml').getroot()}
a,b=read('values'),read('values-ar');assert a.keys()==b.keys()
for key in a:assert sorted(re.findall(r'%[0-9]+\$[sd]',a[key]))==sorted(re.findall(r'%[0-9]+\$[sd]',b[key])),key
for p in (root/'cashbook-feature/src/main/java').rglob('*.kt'):
 assert not re.search('[ء-ي]',p.read_text()),p
 assert not re.search(r'\bText\(\s*"[A-Za-z][A-Za-z ]+"',p.read_text()),p
print(f'PASS: {len(a)} aligned Arabic/English resource keys; format parity; no hardcoded Arabic UI prose')
