# Integration contract — not yet applied to ToDo Shift

## Boundaries

`cashbook-core` owns account/entry rules and backup encoding. `cashbook-feature` owns the local financial file, ViewModel and UI. The host owns the Activity, existing navigation, theme, privacy lock and outer backup policy. The feature requests no network, contacts or broad storage permissions. Android minSdk 26 is the initial contract because the core uses java.time; supporting older Android would need host desugaring review.

Do not replace existing payroll/receipts/debt tables with this ledger. The previously prepared Premium specification already includes monthly due/received/remaining totals, payment allocation and obligations. At integration, map these existing concepts explicitly and choose a single owner per fact.

## Host settings template

These are source-level integration templates, not verified instructions for the current unseen checkout.

```kotlin
// Host settings.gradle.kts, with paths adapted to actual checkout placement:
include(":cashbook-core", ":cashbook-feature")
project(":cashbook-core").projectDir = file("CashBook-Module/core")
project(":cashbook-feature").projectDir = file("CashBook-Module/feature")
```

The app module adds `implementation(project(":cashbook-feature"))`.

The included feature build file targets a host that already supplies AGP and Kotlin 2.x / Compose plugin versions. Read the actual host versions before using it. A Kotlin 1.x host must keep its existing compiler extension configuration instead of applying the Kotlin 2.x Compose plugin. No root Gradle project or wrapper is included, and no dependency versions are guessed.

Set these properties to the actual host-aligned coordinates/versions:

- `cashbook.composeBom`: full platform coordinate, e.g. the exact BOM coordinate already used by the host (not an arbitrary new version).
- `cashbook.activityVersion`: the host activity-compose version.
- `cashbook.lifecycleVersion`: the host Lifecycle version; it must provide lifecycle-runtime-compose.

CompileSdk 35 in this draft reflects the previously documented project baseline, not verification of the latest branch. Align source/target settings with the real host before building.

## Entry point

Create exactly one `CashBookViewModel` at the Activity/root-navigation owner with Android's Application-aware factory; pass that same instance to:

```kotlin
CashBookRoute(vm = cashBookViewModel)
```

The composable contains no Activity, bottom navigation or global theme. It inherits host direction and MaterialTheme. It presently contains an internal title; consolidate with the host toolbar when embedding. Scope must survive tab switches. Never create a ViewModel per inner account or editor: the development store does not coordinate multiple owners/processes.

## Before integration is accepted

1. Native compile, lint and device tests pass; Android atomic-write failure/recovery must be tested.
2. Add host financial-lock checks before displaying data, launching export or accepting restore/deep links. Current standalone source does not implement authentication or encrypted storage.
3. Bind the implemented editor discard guard to the host navigation guard as well. The local dialogs now confirm dirty cancellation; a host tab switch/deep link still needs shared ownership. Saveable draft text survives eligible recreation while the editor remains open.
4. Unify backup: the snapshot is outside automatic Android backup. The host must deliberately include it in its verified backup plan. Never export one module while describing it as a full-app backup.
5. Take baseline copies of host data; migrate only in an explicit tested transaction with rollback. Old Cash Book data migration requires its actual database/backup format, not screenshots.
6. Replace full-file snapshots with a scalable transactional store before high-volume use; current limits: 2,000 accounts, 100,000 entries, 16 MiB payload. The limits are defensive bounds, not a performance guarantee.
7. Finish UI localization, customizable labels, account lifecycle, attachments/items, report exports and accessibility checks per PLAN. Date/time pickers, periods/search/type/order filters and entry editing now exist in source.

## Later shift link

Estimated earnings stay in payroll. Only user-confirmed actual receipt creates a Cash Book income. Persist a unique source-event identity and integration transaction before enabling this link; retries must not duplicate income. The v0.2 ledger deliberately exposes no automated payroll adapter.

Snapshot v2 adds explicit entry time, reads v1 with empty legacy time, and upgrades only through a successful write. The storage filename remains cashbook-v1.bin for continuity. Pass the host week-start setting to CashBookRoute(weekStart = ...).

## v0.3 source contract additions

Account creation supplies an opening date. Entry posting/editing supplies lists of Item and Bill. Items define the total amount. Bills contain display name and content:// URI only, not document bytes; persistent read permission is acquired through the picker. A device/permission-aware attachment-copy and backup strategy is still required. Snapshot version 3 reads versions 1 and 2. Draft extras are stored as a small JSON string via rememberSaveable rather than putting file bytes in saved instance state. The editor requests Android speech recognition via an external recognition Activity; absence/cancellation does not invent transcript text. No broad storage or microphone permission was added.

The reference ledger has spatially fixed columns/control positions. LayoutDirection.Ltr is scoped to the route/editor/drawer so it does not modify host configuration; Arabic text remains Arabic. Validate this behavior under host RTL and accessibility settings before accepting integration. Preview-only customized transaction labels have not yet been connected to native source. Reports currently state their unavailable status rather than generating placeholder output.

## v0.4 density scope

CashBookRoute now wraps its private content with CashBookCompactTheme. Include CashBookCompactTheme.kt when copying module source. The wrapper inherits host colors/shapes and scales typography by 0.85 with an 11sp floor. It does not replace LocalDensity/fontScale or disable Material touch minimums. Keep the wrapper scoped to the financial feature; do not apply the same factor again at the host entry point.
