# Verification — 11 November 2026

## Passed

`bash test-core.sh`: **44 financial-integrity assertions passed** on the local OpenJDK 21 compiler/runtime, source/target 8. Includes Arabic/Persian decimal inputs, ambiguous formatting rejection, bounds, paired transfers, delete/restore, backup round trip, checksum damage rejection, unknown account/date validation, failed read blocks writes, failed write retains prior in-memory and stored snapshots, overflow rejection and reload.

`node preview/test-logic.cjs`: **21 preview-logic assertions passed**, including full JavaScript syntax parse, decimal normalization, integer accounting, transfer cancellation, malformed backups and overflow. These are logic checks using a VM, not browser or native UI tests.

## Attempted but blocked

`node preview/check.cjs`: first browser launch found no Playwright bundled Chromium. Retried with the installed `/usr/bin/chromium`; process aborted with `socket() failed: Operation not permitted` in `process_singleton_posix.cc`. No browser assertions ran. No rendered screenshot or visual QA result is claimed. The script is included for a browser-capable runtime.

## Not executed

Android/Compose compilation, Gradle dependency resolution, Android lint, APK packaging/signing, emulator or real-device testing, AtomicFile fault injection, device persistence/restore, process-death tests, TalkBack/text-scale/keyboard layout checks, host integration and migration. The current workspace has a JDK but no discovered Android SDK, Gradle or Kotlin compiler; it has no checkout of the latest host project.

The saved HTML is an interactive design artifact. The Kotlin UI follows the same basic flows but has not been established to render like it. Do not interpret the preview checks as native acceptance.

## v0.2 verification update

- Financial core: **44** original assertions still pass.
- Query/edit/migration suite: **34** additional assertions pass, covering chronology independent of insertion order, time sorting, period bounds including leap February, Saturday week start, filter-independent running balance, transfers excluded from income, edit-in-place, failed edit rollback, cancelled-entry handling, invalid time, and actual version-1 binary backup migration.
- Preview: **33** logic assertions pass; full current JavaScript parses. Includes period boundaries, custom-range rejection, search and period totals, transfer totals, and time validation.
- Shared-browser check was attempted for the local preview. Its URL policy refused file://. No bypass was attempted; no visual acceptance is claimed.
- Native compile/device checks and browser interaction/layout checks remain unexecuted. The included browser script is updated for v0.2 but is not a passing test result.

## v0.3 actual results

- Original core 44 + query/migration 34 + extras/calculator/migration 29: **107 core assertions passed**.
- **49 preview logic assertions passed**; current full JavaScript parses.
- **13 hierarchy checks passed** for the screenshot-driven HTML structure and all literal element references resolve. These check order and presence, not rendered visual equivalence.
- Native Android compilation/device tests and browser interaction/layout acceptance remain unexecuted. Prior local-browser security restrictions remain; no alternate browser path was used to bypass them. The updated browser script is authored for the current selectors and is not a passed result.
- New device gates: document picker/permissions, revoked or missing document, rotation with draft extras, speech absent/cancelled, IME at large text, side-drawer placement, report unavailability and save-and-continue after items/bills.

## v0.4 density update

49 preview logic assertions and 13 HTML hierarchy checks pass after compact sizing. No financial core/storage changes were made, so the previous 107 core assertions were not needlessly repeated. Native source now uses a feature-scoped compact typography wrapper and shared layout dimensions. Native build/device testing and rendered browser verification remain unexecuted; no screenshot equivalence or APK readiness is claimed.
