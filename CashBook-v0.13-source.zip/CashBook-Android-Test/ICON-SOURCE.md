Lucide Static 1.72.0. Official lucide-static npm distribution. ISC license in LUCIDE-LICENSE.txt. SVG stroke geometry converted to Android VectorDrawable without raster images. Stable IDs in ICON-CATALOG.json.
Four matching stroke icons (kettle, screwdriver, tooth, beach) are original project geometry; remaining icons are Lucide ISC.
