// Authored browser acceptance checks for v0.3. Not a passing browser test result.
const {chromium}=require('playwright');const path=require('path');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:412,height:900}});let checks=0;const errors=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
 function ok(value,label){checks++;if(!value)throw Error(label)}
 await page.goto('file://'+path.join(__dirname,'CashBook-Preview.html'));
 ok(await page.locator('#balance').innerText()==='2,290.00','initial balance');
 ok(await page.locator('[data-period]').count()===5,'five reference periods');
 await page.locator('#cashOut').click();ok(await page.locator('#kind').inputValue()==='EXPENSE','direct expense');
 ok(!(await page.locator('#editorAccount').isVisible()),'no repeated account choice');
 await page.locator('#amount').fill('١٢٫٥٠');await page.locator('#note').fill('first');await page.locator('#saveContinue').click();
 ok(await page.locator('#entryDialog').evaluate(n=>n.open),'continue keeps editor');ok(await page.locator('#amount').inputValue()==='','clears amount');
 await page.locator('#amount').fill('1,5');await page.locator('#saveContinue').click();ok((await page.locator('#entryError').innerText()).includes('لم تُحفظ'),'failed save error');ok(await page.locator('#amount').inputValue()==='1,5','failed save retains draft');
 await page.locator('#amount').fill('7.50');await page.locator('#saveExit').click();ok(await page.locator('#balance').innerText()==='2,270.00','saved two expenses');
 await page.locator('#searchToggle').click();await page.locator('#search').fill('first');ok(await page.locator('#list .record').count()===1,'search');
 await page.locator('#list .record').click();await page.locator('#editEntry').click();await page.locator('#amount').fill('10');await page.locator('#saveExit').click();ok(await page.locator('#balance').innerText()==='2,272.50','edit not duplicate');
 await page.locator('#searchClose').click();await page.locator('#cashIn').click();await page.locator('#itemsOpen').click();await page.locator('#itemName').fill('ورق');await page.locator('#itemQuantity').fill('3');await page.locator('#itemUnit').fill('12.50');await page.locator('#addItem').click();await page.locator('#itemsApply').click();ok(await page.locator('#amount').inputValue()==='37.50','items compute amount');await page.locator('#saveExit').click();
 ok(await page.locator('#balance').innerText()==='2,310.00','item total posting');
 await page.reload();ok(await page.locator('#balance').innerText()==='2,310.00','reload retains data');
 await page.locator('#navOpen').click();await page.locator('[data-page="summary"]').click();ok(!(await page.locator('#quick').isVisible()),'summary no entry bar');ok(await page.locator('#list .summary').count()===3,'per-account summary');
 await page.setViewportSize({width:320,height:750});ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'no viewport overflow');
 await page.evaluate(()=>localStorage.setItem('cashbook-design-v01','broken'));await page.reload();ok(await page.locator('#cashIn').isDisabled(),'read failure blocks writes');ok(await page.evaluate(()=>localStorage.getItem('cashbook-design-v01'))==='broken','bad bytes retained');ok(errors.length===0,'no JS errors');
 console.log('PASS: '+checks+' browser assertions');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
