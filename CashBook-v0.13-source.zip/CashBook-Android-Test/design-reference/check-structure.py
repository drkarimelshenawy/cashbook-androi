"""Checks screenshot-driven hierarchy; does not claim rendered visual equivalence."""
from html.parser import HTMLParser
from pathlib import Path
import re
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.stack=[];self.ids={};self.nodes=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs);node={'tag':tag,'attrs':a,'parent':self.stack[-1] if self.stack else None};self.nodes.append(node)
  if 'id' in a:
   assert a['id'] not in self.ids,a['id'];self.ids[a['id']]=node
  if tag not in ('input','meta','br','hr','img','link'):self.stack.append(node)
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i]['tag']==tag:del self.stack[i:];break
p=Parser();s=Path(__file__).with_name('CashBook-Preview.html').read_text();p.feed(s)
def children(id):return [n['attrs'].get('id') or n['attrs'].get('class') or n['tag'] for n in p.nodes if n['parent'] is p.ids[id]]
assert children('app')==['bar','periods','period-line','searchPanel','columns','list','quick','bottomTotals','previewNotice']
assert children('periods')==['button']*5
assert children('quick')==['cashIn','cashOut']
assert p.ids['quick']['parent'] is p.ids['app'] and p.ids['bottomTotals']['parent'] is p.ids['app']
assert p.ids['source']['parent']['attrs']['id']=='editorAccount'
assert p.ids['editorAccount']['attrs']['class']=='editor-account'
assert [n['attrs'].get('id') for n in p.nodes if n['parent'] and n['parent']['attrs'].get('class')=='save-bar']==['saveExit','saveContinue']
assert children('kindButtons')==['button','button']
assert p.ids['date']['parent']['attrs']['class']=='date-box'
assert p.ids['time']['parent']['attrs']['class']=='date-time'
assert p.ids['billsOpen']['parent'] is p.ids['itemsOpen']['parent']
assert p.ids['navDialog']['attrs']['class']=='drawer'
assert not any(n['attrs'].get('class') in ('balance','stats','tabs','accounts') for n in p.nodes)
script=s.split('<script>')[1].split('</script>')[0]
for id in re.findall(r"\$\('([^']+)'\)",script):assert id in p.ids,id
print('PASS: 13 screenshot-layout structure checks; all literal UI references resolve')
