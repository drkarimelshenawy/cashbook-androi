// Logic checks only. These do not establish browser layout or Android correctness.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/CashBook-Preview.html','utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(script); // Syntax-check entire interactive preview.
const context=vm.createContext({document:{getElementById:()=>({})},localStorage:{setItem(){}},structuredClone,console});
vm.runInContext(script.slice(0,script.indexOf('try{const raw=')),context);
let n=0;function eq(expr,result){assert.strictEqual(vm.runInContext(expr,context),result);n++}
function fail(expr){assert.throws(()=>vm.runInContext(expr,context));n++}
eq('parse("١٢٫٥٠")','1250');eq('parse("۱۲.۵۰")','1250');eq('parse("-50",true)','-5000');
for(const s of ['1,5','1,000','1.001','-1','NaN','1e4',''])fail('parse('+JSON.stringify(s)+')');
vm.runInContext('state=structuredClone(sample)',context);
eq('String(balance("cash"))','229000');eq('String(balance("bank"))','1340000');
eq('validate(state).version',1);
vm.runInContext('state.entries.find(e=>e.kind==="TRANSFER").deleted=true',context);
eq('String(balance("cash"))','129000');eq('String(balance("bank"))','1440000');
fail('validate({...state,version:99})');
fail('validate({...state,accounts:[...state.accounts,state.accounts[0]]})');
fail('validate({...state,entries:[{...state.entries[0],date:"2026-02-30"}]})');
fail('validate({...state,entries:[{...state.entries[0],kind:"TRANSFER",target:"bank"}]})');
fail('validate({...state,entries:[{...state.entries[0],minor:"9223372036854775808"}]})');
eq('money("-501")','-5.01');
eq('periodRange("WEEKLY","2026-11-11")[0]','2026-11-07');
eq('periodRange("WEEKLY","2026-11-11")[1]','2026-11-13');
eq('periodRange("MONTHLY","2024-02-10")[1]','2024-02-29');
fail('periodRange("CUSTOM","2026-11-11","2026-12-01","2026-11-01")');
vm.runInContext('state=structuredClone(sample)',context);
eq('view(state,"cash",{range:["2026-11-11","2026-11-11"]}).rows.length',2);
eq('String(view(state,"cash",{range:["2026-11-11","2026-11-11"]}).income)','0');
eq('String(view(state,"cash",{search:"مواصلات"}).rows[0].running)','241500');
eq('view(state,"cash",{search:"غائب"}).rows.length',0);
eq('String(view(state,"bank",{}).income)','240000');
eq('String(view(state,"cash",{}).tin)','100000');
fail('validate({...state,version:2,entries:[{...state.entries[0],time:"25:01"}]})');
eq('validate({...state,version:2,entries:state.entries.map(e=>({...e,time:"12:30"}))}).version',2);
eq('calc("125+75*2")','27500');eq('calc("(125+75)*2")','40000');eq('calc("١٢٫٥ + ٢٫٥")','1500');eq('calc("1/3")','33');eq('calc("2/3")','67');eq('calc("-1.005")','-101');
fail('calc("1/0")');fail('calc("alert(1)")');fail('calc("1,5")');fail('calc("92233720368547758.08")');
eq('String(itemTotal([{name:"A",quantity:3,unit:"1250"}]))','3750');fail('itemTotal([{name:"A",quantity:0,unit:"1250"}])');
vm.runInContext('state=normalize(structuredClone(sample))',context);
eq('validate(state).version',3);eq('state.entries[0].items.length',0);
fail('validate({...state,entries:[{...state.entries[0],items:[{name:"A",quantity:1,unit:"1"}]}]})');
fail('validate({...state,entries:[{...state.entries[0],bills:[{name:"bad",data:"javascript:alert(1)"}]}]})');
console.log('PASS: '+n+' preview logic assertions; full JavaScript parses');
