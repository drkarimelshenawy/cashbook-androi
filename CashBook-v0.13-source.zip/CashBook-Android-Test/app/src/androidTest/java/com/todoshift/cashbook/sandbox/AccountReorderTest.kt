package com.todoshift.cashbook.sandbox

import android.os.ParcelFileDescriptor
import android.view.accessibility.AccessibilityNodeInfo
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.todoshift.cashbook.core.Ledger
import com.todoshift.cashbook.ui.AndroidLedgerStore
import com.todoshift.cashbook.ui.CashBookViewModel
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Destructive fixture ONLY for a disposable emulator. Phase two runs in a NEW process. */
@RunWith(AndroidJUnit4::class)
class AccountReorderTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val instrument get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrument.targetContext
    private val expectedFile get() = File(context.noBackupFilesDir, "reorder-test-expected.txt")
    private fun dismissSystemDialog() {
        val root = instrument.uiAutomation.rootInActiveWindow ?: return
        if (root.packageName?.toString() !in listOf("android", "com.android.systemui")) return
        if (root.findAccessibilityNodeInfosByText("System UI").isEmpty()) return
        var button = root.findAccessibilityNodeInfosByText("Wait").firstOrNull() ?: return
        while (!button.isClickable && button.parent != null) button = button.parent
        button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        instrument.uiAutomation.waitForIdle(750, 15000)
    }
    private fun capture(name: String) {
        dismissSystemDialog(); compose.waitForIdle(); instrument.uiAutomation.waitForIdle(750, 15000)
        val dir = File(context.getExternalFilesDir(null), "reorder-screenshots").apply { mkdirs() }
        val bytes = ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("screencap -p")).use { it.readBytes() }
        assertTrue(bytes.size > 8 && bytes[0] == 0x89.toByte()); File(dir, name).writeBytes(bytes)
    }
    private fun openPicker() {
        compose.waitUntil(60000) { compose.onAllNodesWithTag("account_picker_open").fetchSemanticsNodes().isNotEmpty() }
        dismissSystemDialog()
        compose.onNodeWithTag("account_picker_open").performClick()
        compose.onNodeWithTag("accounts_edit").performClick()
    }
    private fun awaitSaved(scenario: ActivityScenario<MainActivity>, ids: List<String>) {
        compose.waitUntil(60000) {
            var saved = false
            scenario.onActivity {
                val state = ViewModelProvider(it)[CashBookViewModel::class.java].state.value
                saved = !state.busy && state.error == null && state.snapshot?.accounts?.map { a -> a.id } == ids
            }
            saved
        }
        // Read only after the writer completed, then verify bytes using a fresh store/ledger.
        assertEquals(ids, Ledger(AndroidLedgerStore(context)).load().accounts.map { it.id })
    }
    private fun drag(id: String, pixels: Float, cancelDrag: Boolean = false) {
        dismissSystemDialog()
        compose.onNodeWithTag("account_drag_$id", useUnmergedTree = true).performTouchInput {
            down(center); advanceEventTime(700); moveBy(Offset(0f, pixels), delayMillis = 100)
        }
        compose.onNodeWithTag("accounts_dialog").performTouchInput { if (cancelDrag) cancel() else up() }
    }
    @Test fun dragAndPersist() {
        context.noBackupFilesDir.listFiles()?.forEach { it.delete() }
        val ledger = Ledger(AndroidLedgerStore(context)); ledger.load()
        val original = (1..18).map { ledger.addAccount("حساب %02d".format(it), "EGP", if (it == 1) 10000 else 0) }
        ledger.post(Ledger.Kind.EXPENSE, original.first(), null, 100, "عملية ثابتة", "2026-11-11", "10:00")
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            openPicker()
            val firstBounds = compose.onNodeWithTag("account_row_${original[0]}").getUnclippedBoundsInRoot()
            val firstHeight = (firstBounds.bottom.value - firstBounds.top.value) * context.resources.displayMetrics.density
            drag(original[0], firstHeight * 2.15f)
            awaitSaved(scenario, original.toMutableList().apply { add(2, removeAt(0)) })
            drag(original[0], -firstHeight * 2.15f)
            awaitSaved(scenario, original)
            // Cancellation must restore the preview and must not persist a new order.
            drag(original[0], firstHeight * 1.15f, cancelDrag = true)
            awaitSaved(scenario, original)
            // Hold at the lower edge to move an account beyond the initially visible rows.
            val listBounds = compose.onNodeWithTag("accounts_list").getUnclippedBoundsInRoot()
            val handleBounds = compose.onNodeWithTag("account_drag_${original[0]}", useUnmergedTree = true).getUnclippedBoundsInRoot()
            val delta = (listBounds.bottom.value - ((handleBounds.top.value + handleBounds.bottom.value) / 2) - 3f) * context.resources.displayMetrics.density
            compose.onNodeWithTag("account_drag_${original[0]}", useUnmergedTree = true).performTouchInput {
                down(center); advanceEventTime(700); moveBy(Offset(0f, delta), delayMillis = 150)
            }
            compose.mainClock.advanceTimeBy(2500)
            compose.onNodeWithTag("accounts_dialog").performTouchInput { up() }
            val expected = original.drop(1) + original.first()
            awaitSaved(scenario, expected)
            capture("accounts-last.png")
            compose.onNodeWithTag("accounts_list").performScrollToIndex(0)
            capture("accounts-reordered.png")
            compose.onNodeWithTag("accounts_search").performTextInput("حساب 18")
            compose.onNodeWithTag("account_drag_${original.last()}", useUnmergedTree = true)
                .assert(SemanticsMatcher.keyNotDefined(SemanticsActions.CustomActions))
            assertEquals(expected, Ledger(AndroidLedgerStore(context)).load().accounts.map { it.id })
            expectedFile.writeText(expected.joinToString("\n"))
            File(context.noBackupFilesDir, "reorder-test-pid.txt").writeText(android.os.Process.myPid().toString())
        }
    }
    @Test fun verifyAfterProcessRestart() {
        val expected = expectedFile.readLines().filter { it.isNotBlank() }
        assertEquals(18, expected.size)
        val previousPid = File(context.noBackupFilesDir, "reorder-test-pid.txt").readText().trim().toInt()
        assertNotEquals("Verification must use a different application process", previousPid, android.os.Process.myPid())
        android.util.Log.i("AccountReorderTest", "Restart verified: old PID=$previousPid new PID=${android.os.Process.myPid()}")
        val snapshot = Ledger(AndroidLedgerStore(context)).load()
        assertEquals(expected, snapshot.accounts.map { it.id })
        assertEquals(9900L, snapshot.balance(expected.last()))
        assertEquals(1, snapshot.entries.size)
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            openPicker(); awaitSaved(scenario, expected)
            compose.onNodeWithTag("account_row_${expected.first()}").assertIsDisplayed()
            assertEquals("حساب 02", snapshot.accounts.first().name)
            capture("accounts-after-restart.png")
        }
    }
}
