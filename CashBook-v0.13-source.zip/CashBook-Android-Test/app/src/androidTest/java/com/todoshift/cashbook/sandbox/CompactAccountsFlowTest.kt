package com.todoshift.cashbook.sandbox

import android.accessibilityservice.AccessibilityServiceInfo
import android.os.ParcelFileDescriptor
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.todoshift.cashbook.core.Ledger
import com.todoshift.cashbook.ui.AndroidLedgerStore
import com.todoshift.cashbook.ui.CashBookViewModel
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Disposable emulator only. Harness seeds v3 data and installs 0.9 OVER 0.8 before phase one. */
@RunWith(AndroidJUnit4::class)
class CompactAccountsFlowTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val instrument get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrument.targetContext
    private lateinit var scenario: ActivityScenario<MainActivity>
    private fun waitState(check: (Ledger.Snapshot) -> Boolean): Ledger.Snapshot {
        var result: Ledger.Snapshot? = null
        var lastError: String? = null
        compose.waitUntil(90000) {
            scenario.onActivity {
                val state = ViewModelProvider(it)[CashBookViewModel::class.java].state.value
                lastError = state.error
                if (!state.busy && state.error == null && state.snapshot?.let(check) == true) result = state.snapshot
            }
            result != null
        }
        assertNull(lastError); return result!!
    }
    private fun step(text: String) {
        instrument.sendStatus(2, android.os.Bundle().apply { putString("stream", "\nSTEP: $text\n") })
    }
    private fun hideKeyboard() {
        val info = instrument.uiAutomation.serviceInfo
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        instrument.uiAutomation.serviceInfo = info
        if (instrument.uiAutomation.windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            instrument.uiAutomation.waitForIdle(750, 15000)
        }
    }
    private fun dismissSystemDialog() {
        val root = instrument.uiAutomation.rootInActiveWindow ?: return
        if (root.packageName?.toString() !in listOf("android", "com.android.systemui")) return
        if (root.findAccessibilityNodeInfosByText("System UI").isEmpty()) return
        var button = root.findAccessibilityNodeInfosByText("Wait").firstOrNull() ?: return
        while (!button.isClickable && button.parent != null) button = button.parent
        button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        instrument.uiAutomation.waitForIdle(750, 15000)
    }
    private fun capture(name: String) {
        dismissSystemDialog(); hideKeyboard(); compose.waitForIdle(); instrument.uiAutomation.waitForIdle(750, 15000)
        val dir = File(context.getExternalFilesDir(null), "compact-screenshots").apply { mkdirs() }
        val bytes = ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("screencap -p")).use { it.readBytes() }
        assertTrue(bytes.size > 8 && bytes[0] == 0x89.toByte()); File(dir,name).writeBytes(bytes)
    }
    private fun picker() {
        hideKeyboard(); dismissSystemDialog()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isEmpty()) compose.onNodeWithTag("account_picker_open").performClick()
    }
    private fun closePicker() {
        hideKeyboard()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isNotEmpty()) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            compose.waitForIdle()
        }
    }
    private fun choosePreset(index:Int) {
        hideKeyboard();compose.onNodeWithTag("button_presets").performClick()
        compose.onNodeWithTag("button_preset_$index").performScrollTo().performClick()
    }
    private fun editLabel(income:Boolean,value:String) {
        hideKeyboard();compose.onNodeWithTag(if(income) "edit_incoming" else "edit_outgoing").performClick()
        compose.onNodeWithTag(if(income) "custom_incoming" else "custom_outgoing").performTextReplacement(value)
        hideKeyboard();compose.onNodeWithTag("label_save").performClick()
    }
    private fun row(id:String) {
        compose.onNodeWithTag("accounts_list").performScrollToNode(hasTestTag("account_row_$id"))
        compose.onNodeWithTag("account_row_$id").performClick()
    }
    @Test fun compactAccountsAndNavigation() {
        val legacy=Ledger(AndroidLedgerStore(context)).load()
        assertEquals(-1000L,legacy.balance("old"));assertEquals("★",legacy.accounts.first().icon)
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use {
            waitState{it.accounts.size==1};dismissSystemDialog()
            step("upgrade preserved v4 data; compact creation")
            compose.onAllNodesWithTag("drawer_open").assertCountEquals(0)
            picker();compose.onNodeWithTag("active_account",useUnmergedTree=true).assertExists()
            compose.onNodeWithTag("accounts_add").performClick()
            compose.onNodeWithTag("account_name").performTextReplacement("مضغوط")
            compose.onNodeWithTag("account_opening").performTextReplacement("-100.50")
            hideKeyboard();capture("compact-create.png")
            compose.onAllNodesWithTag("custom_incoming").assertCountEquals(0)
            choosePreset(3);editLabel(true,"راتب");editLabel(false,"فواتير")
            compose.onNodeWithTag("button_presets").performClick();compose.onNodeWithTag("save_personal_preset").performClick()
            waitState{it.preferences.presets.size==1}
            compose.onNodeWithTag("account_icon_picker").performClick()
            compose.onNodeWithTag("icon_search").performTextReplacement("بطاقة")
            hideKeyboard();compose.onNodeWithTag("favorite_💳").performClick()
            waitState{it.preferences.favorites.contains("💳")}
            capture("icon-search.png")
            compose.onNodeWithTag("icon_💳").performClick()
            waitState{it.preferences.recent.firstOrNull()=="💳"}
            compose.onNodeWithTag("account_create_save").performClick()
            val created=waitState{it.accounts.size==2};val a=created.accounts.first{it.name=="مضغوط"}.id
            assertEquals(-10050L,created.balance(a));assertEquals("راتب",created.accounts.first{it.id==a}.incomingLabel)
            assertTrue(created.accounts.first{it.id==a}.createdDate.isNotBlank());assertTrue(created.accounts.first{it.id==a}.openingDate.isNotBlank())
            picker();row(a)
            compose.onNodeWithTag("quick_income").assertTextContains("راتب")
            compose.onNodeWithTag("quick_income").performClick();compose.onNodeWithTag("entry_amount").performTextInput("200")
            hideKeyboard();compose.onNodeWithTag("save_exit").performClick();waitState{it.balance(a)==9950L}
            step("negative opening and custom labels persisted; personal template reuse")
            picker();compose.onNodeWithTag("accounts_add").performClick()
            compose.onNodeWithTag("account_name").performTextReplacement("قالب شخصي")
            hideKeyboard();compose.onNodeWithTag("button_presets").performClick();compose.onNodeWithTag("personal_preset_0").performScrollTo().performClick()
            compose.onNodeWithTag("account_create_save").performClick()
            val b=waitState{it.accounts.size==3}.accounts.first{it.name=="قالب شخصي"}.id
            assertEquals("راتب",waitState{true}.accounts.first{it.id==b}.incomingLabel)
            picker();compose.onNodeWithTag("accounts_edit").performClick();row(a)
            compose.onNodeWithTag("account_delete").performClick()
            compose.onNodeWithText("الحذف غير متاح").assertExists()
            compose.onAllNodesWithTag("account_delete_confirm").assertCountEquals(0)
            capture("protected-delete.png")
            compose.onNodeWithText("أرشفة بدلًا من الحذف").performClick();waitState{it.accounts.first{x->x.id==a}.archived}
            compose.onNodeWithTag("archived_accounts").performClick();row(a)
            compose.onNodeWithTag("account_archive").performClick();waitState{!it.accounts.first{x->x.id==a}.archived}
            // Close and reopen to reset archive/edit mode before drag regression.
            closePicker();picker();compose.onNodeWithTag("accounts_edit").performClick()
            val before=waitState{true}.accounts.map{it.id}
            compose.onNodeWithTag("account_drag_${before[0]}",useUnmergedTree=true).performTouchInput {
                down(center);advanceEventTime(650);moveBy(androidx.compose.ui.geometry.Offset(0f,85f),300)
            }
            compose.onNodeWithTag("accounts_dialog").performTouchInput {up()}
            val ordered=waitState{it.accounts.map{a->a.id}!=before}.accounts.map{it.id}
            File(context.noBackupFilesDir,"compact-order.txt").writeText(ordered.joinToString("\n"))
            capture("account-order.png")
            closePicker()
            compose.onNodeWithTag("section_options").performClick()
            compose.onAllNodesWithText("اختيار فترة").assertCountEquals(0)
            compose.onAllNodesWithText("كل العمليات").assertCountEquals(0)
            capture("section-menu.png")
            compose.onNodeWithTag("data_management_open").performClick()
            compose.onNodeWithText("المعاملات المحذوفة").assertExists();compose.onNodeWithText("نسخة احتياطية").assertExists();compose.onNodeWithText("استعادة نسخة").assertExists()
            compose.onNodeWithText("إغلاق").performClick()
            compose.onNodeWithTag("summary_open").performClick();compose.onNodeWithText("الملخص").assertExists()
            File(context.noBackupFilesDir,"compact-test-pid.txt").writeText(android.os.Process.myPid().toString())
            step("compact UI, favorites, templates, protection, archive/restore, drag and menus passed")
        }
    }
    @Test fun verifyRestart() {
        val previous=File(context.noBackupFilesDir,"compact-test-pid.txt").readText().trim().toInt();assertNotEquals(previous,android.os.Process.myPid())
        val stored=Ledger(AndroidLedgerStore(context)).load()
        assertEquals(3,stored.accounts.size);assertEquals(File(context.noBackupFilesDir,"compact-order.txt").readLines(),stored.accounts.map{it.id})
        assertEquals("راتب",stored.preferences.presets.first().incoming);assertTrue(stored.preferences.favorites.contains("💳"));assertEquals("💳",stored.preferences.recent.first())
        val a=stored.accounts.first{it.name=="مضغوط"};assertFalse(a.archived);assertEquals(9950L,stored.balance(a.id));assertEquals("فواتير",a.outgoingLabel)
        android.util.Log.i("CompactAccountsFlowTest","Restart verified: old PID=$previous new PID=${android.os.Process.myPid()}")
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use {
            waitState{it.accounts.size==3};picker();row(a.id)
            compose.onNodeWithTag("quick_income").assertTextContains("راتب");compose.onNodeWithTag("quick_expense").assertTextContains("فواتير")
            capture("after-restart.png")
        }
    }
    @Test fun keyboardFooter() {
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use {
            waitState{it.accounts.isNotEmpty()};picker()
            compose.onNodeWithTag("accounts_search").performTextInput("م")
            compose.waitForIdle();instrument.uiAutomation.waitForIdle(750,15000)
            compose.onNodeWithTag("accounts_add").assertIsDisplayed()
            val dir=File(context.getExternalFilesDir(null),"compact-screenshots").apply{mkdirs()}
            val bytes=ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("screencap -p")).use{it.readBytes()}
            File(dir,"accounts-keyboard.png").writeBytes(bytes)
        }
    }

}
