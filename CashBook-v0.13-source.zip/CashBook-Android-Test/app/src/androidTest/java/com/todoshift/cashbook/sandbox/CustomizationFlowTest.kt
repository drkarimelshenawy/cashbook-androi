package com.todoshift.cashbook.sandbox

import android.accessibilityservice.AccessibilityServiceInfo
import android.os.ParcelFileDescriptor
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.todoshift.cashbook.core.Ledger
import com.todoshift.cashbook.ui.AndroidLedgerStore
import com.todoshift.cashbook.ui.CashBookViewModel
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Disposable emulator only. Harness seeds v3 data and installs 0.9 OVER 0.8 before phase one. */
@RunWith(AndroidJUnit4::class)
class CustomizationFlowTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val instrument get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrument.targetContext
    private lateinit var scenario: ActivityScenario<MainActivity>
    private fun waitState(check: (Ledger.Snapshot) -> Boolean): Ledger.Snapshot {
        var result: Ledger.Snapshot? = null
        var lastError: String? = null
        compose.waitUntil(90000) {
            scenario.onActivity {
                val state = ViewModelProvider(it)[CashBookViewModel::class.java].state.value
                lastError = state.error
                if (!state.busy && state.error == null && state.snapshot?.let(check) == true) result = state.snapshot
            }
            result != null
        }
        assertNull(lastError); return result!!
    }
    private fun step(text: String) {
        instrument.sendStatus(2, android.os.Bundle().apply { putString("stream", "\nSTEP: $text\n") })
    }
    private fun hideKeyboard() {
        val info = instrument.uiAutomation.serviceInfo
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        instrument.uiAutomation.serviceInfo = info
        if (instrument.uiAutomation.windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            instrument.uiAutomation.waitForIdle(750, 15000)
        }
    }
    private fun dismissSystemDialog() {
        val root = instrument.uiAutomation.rootInActiveWindow ?: return
        if (root.packageName?.toString() !in listOf("android", "com.android.systemui")) return
        if (root.findAccessibilityNodeInfosByText("System UI").isEmpty()) return
        var button = root.findAccessibilityNodeInfosByText("Wait").firstOrNull() ?: return
        while (!button.isClickable && button.parent != null) button = button.parent
        button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        instrument.uiAutomation.waitForIdle(750, 15000)
    }
    private fun capture(name: String) {
        dismissSystemDialog(); hideKeyboard(); compose.waitForIdle(); instrument.uiAutomation.waitForIdle(750, 15000)
        val dir = File(context.getExternalFilesDir(null), "customization-screenshots").apply { mkdirs() }
        val bytes = ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("screencap -p")).use { it.readBytes() }
        assertTrue(bytes.size > 8 && bytes[0] == 0x89.toByte()); File(dir,name).writeBytes(bytes)
    }
    private fun picker() {
        hideKeyboard(); dismissSystemDialog()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isEmpty()) compose.onNodeWithTag("account_picker_open").performClick()
    }
    private fun closePicker() {
        hideKeyboard()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isNotEmpty()) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            compose.waitForIdle()
        }
    }
    private fun defaults(preset: Int) {
        closePicker(); compose.onNodeWithTag("drawer_open").performClick()
        compose.onNodeWithTag("default_settings_open").performClick()
        choosePreset(preset); hideKeyboard()
        compose.onNodeWithTag("defaults_save").performClick()
        waitState { if (preset == 3) it.defaults.incoming == "قبض" else it.defaults.incoming == "استلام" }
    }
    private fun choosePreset(index: Int) {
        compose.onNodeWithTag("button_presets").performScrollTo().performClick()
        compose.onNodeWithTag("button_preset_$index").performScrollTo().performClick()
    }
    private fun icon(symbol: String, group: Int = 0) {
        hideKeyboard()
        compose.onNodeWithTag("account_icon_picker").performScrollTo().performClick()
        if (group != 0) compose.onNodeWithTag("icon_group_$group").performScrollTo().performClick()
        compose.onNodeWithTag("icon_$symbol").performScrollTo().performClick()
    }
    private fun create(name: String, preset: Int? = null, symbol: String? = null, customSymbol: String? = null): String {
        picker(); compose.onNodeWithTag("accounts_add").performClick()
        compose.onNodeWithTag("account_name").performTextReplacement(name)
        if (symbol != null) icon(symbol)
        if (customSymbol != null) {
            hideKeyboard();compose.onNodeWithTag("account_icon_picker").performScrollTo().performClick()
            compose.onNodeWithTag("custom_icon_open").performClick()
            compose.onNodeWithTag("custom_icon").performTextReplacement(customSymbol)
            hideKeyboard();compose.onNodeWithTag("custom_icon_apply").performClick()
        }
        if (preset != null) choosePreset(preset)
        hideKeyboard();compose.onNodeWithTag("account_create_save").performClick()
        val snapshot = waitState { it.accounts.any { a -> a.name == name } }
        return snapshot.accounts.first { it.name == name }.id
    }
    private fun select(id: String, editing: Boolean = false) {
        picker()
        if (editing) compose.onNodeWithTag("accounts_edit").performClick()
        compose.onNodeWithTag("accounts_list").performScrollToNode(hasTestTag("account_row_$id"))
        hideKeyboard();compose.onNodeWithTag("account_row_$id").performClick()
    }
    @Test fun customizeDefaultsAccountsAndIcons() {
        val legacy = Ledger(AndroidLedgerStore(context)).load()
        assertEquals(1, legacy.accounts.size);assertEquals(123450L, legacy.balance("legacy"))
        assertEquals("إيراد",legacy.accounts.first().incomingLabel);assertEquals("",legacy.accounts.first().icon)
        scenario = ActivityScenario.launch(MainActivity::class.java)
        scenario.use {
            waitState { it.accounts.size == 1 };dismissSystemDialog()
            step("legacy loaded; changing defaults")
            defaults(3)
            step("defaults saved; creating account with emoji")
            val a = create("افتراضي", symbol = "💳")
            val created = waitState { it.accounts.size == 2 }
            assertEquals("قبض",created.accounts.first { it.id == a }.incomingLabel)
            assertEquals("دفع",created.accounts.first { it.id == a }.outgoingLabel)
            assertEquals("💳",created.accounts.first { it.id == a }.icon)
            assertEquals("إيراد",created.accounts.first { it.id == "legacy" }.incomingLabel)
            step("account created with copied defaults and emoji")
            select(a)
            compose.onNodeWithTag("quick_income").assertTextContains("قبض")
            compose.onNodeWithTag("quick_expense").assertTextContains("دفع")
            compose.onNodeWithTag("account_picker_open").assertTextContains("💳",substring = true)
            compose.onNodeWithTag("quick_income").performClick()
            compose.onNodeWithTag("entry_amount").performTextInput("100.50")
            hideKeyboard();compose.onNodeWithTag("save_exit").performClick()
            waitState { it.balance(a) == 10050L }
            step("income saved; editing account labels and emoji")
            select(a,editing = true)
            compose.onNodeWithTag("account_edit_name").performTextReplacement("حساب مميز")
            icon("💼",1);choosePreset(2)
            compose.onNodeWithTag("custom_incoming").performScrollTo().performTextReplacement("مرتب")
            compose.onNodeWithTag("custom_outgoing").performScrollTo().performTextReplacement("فواتير")
            compose.onNodeWithTag("custom_outgoing").performImeAction();hideKeyboard()
            compose.onNodeWithTag("account_details_save").performClick()
            val edited = waitState { it.accounts.first { x -> x.id == a }.incomingLabel == "مرتب" }
            assertEquals(10050L,edited.balance(a));assertEquals("قبض",edited.defaults.incoming)
            compose.onNodeWithTag("accounts_edit").performClick()
            compose.onNodeWithTag("account_row_$a").performClick()
            compose.onNodeWithTag("quick_income").assertTextContains("مرتب")
            compose.onNodeWithTag("quick_expense").assertTextContains("فواتير")
            step("account edit persisted; checking expense")
            capture("custom-account.png")
            compose.onNodeWithTag("quick_expense").performClick()
            compose.onNodeWithTag("entry_amount").performTextInput("20")
            hideKeyboard();compose.onNodeWithTag("save_exit").performClick()
            waitState { it.balance(a) == 8050L }
            step("expense saved; creating independent labels and custom symbol")
            create("مخصص",preset = 1,customSymbol = "★")
            step("custom symbol saved; changing future defaults")
            defaults(9)
            create("جديد")
            step("new account copied changed defaults")
            val final = waitState { it.accounts.size == 4 }
            assertEquals("استلام",final.defaults.incoming);assertEquals("تسليم",final.defaults.outgoing)
            assertEquals("مرتب",final.accounts.first { it.id == a }.incomingLabel)
            assertEquals("💼",final.accounts.first { it.id == a }.icon)
            assertEquals("وارد",final.accounts.first { it.name == "مخصص" }.incomingLabel)
            assertEquals("★",final.accounts.first { it.name == "مخصص" }.icon)
            assertEquals("استلام",final.accounts.first { it.name == "جديد" }.incomingLabel)
            assertEquals("",final.accounts.first { it.name == "جديد" }.icon)
            assertEquals(123450L,final.balance("legacy"));assertEquals("old-entry",final.entries.first().id)
            assertEquals(listOf(Ledger.Kind.INCOME,Ledger.Kind.EXPENSE),final.entries.filter { it.accountId == a }.map { it.kind })
            picker();capture("account-symbols.png");closePicker()
            compose.onNodeWithTag("drawer_open").performClick();compose.onNodeWithTag("default_settings_open").performClick()
            capture("defaults.png")
            step("all customization assertions passed")
            File(context.noBackupFilesDir,"customization-test-pid.txt").writeText(android.os.Process.myPid().toString())
        }
    }
    @Test fun verifyAfterProcessRestart() {
        val previous = File(context.noBackupFilesDir,"customization-test-pid.txt").readText().trim().toInt()
        assertNotEquals(previous,android.os.Process.myPid())
        val stored = Ledger(AndroidLedgerStore(context)).load()
        assertEquals(4,stored.accounts.size);assertEquals("استلام",stored.defaults.incoming);assertEquals("تسليم",stored.defaults.outgoing)
        val a = stored.accounts.first { it.name == "حساب مميز" }
        assertEquals("مرتب",a.incomingLabel);assertEquals("فواتير",a.outgoingLabel);assertEquals("💼",a.icon);assertEquals(8050L,stored.balance(a.id))
        assertEquals("★",stored.accounts.first { it.name == "مخصص" }.icon)
        assertEquals("استلام",stored.accounts.first { it.name == "جديد" }.incomingLabel)
        assertEquals(123450L,stored.balance("legacy"));assertEquals(3,stored.entries.size)
        android.util.Log.i("CustomizationFlowTest","Restart verified: old PID=$previous new PID=${android.os.Process.myPid()}")
        scenario = ActivityScenario.launch(MainActivity::class.java)
        scenario.use {
            waitState { it.accounts.size == 4 };select(a.id)
            compose.onNodeWithTag("quick_income").assertTextContains("مرتب")
            compose.onNodeWithTag("quick_expense").assertTextContains("فواتير")
            compose.onNodeWithTag("account_picker_open").assertTextContains("💼",substring = true)
            capture("after-restart.png")
        }
    }
}
