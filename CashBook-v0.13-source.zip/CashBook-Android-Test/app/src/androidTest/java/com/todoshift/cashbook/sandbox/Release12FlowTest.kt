package com.todoshift.cashbook.sandbox

import android.accessibilityservice.AccessibilityServiceInfo
import android.os.ParcelFileDescriptor
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.todoshift.cashbook.core.Ledger
import com.todoshift.cashbook.ui.AndroidLedgerStore
import com.todoshift.cashbook.ui.CashBookViewModel
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Disposable emulator only. Harness seeds v3 data and installs 0.9 OVER 0.8 before phase one. */
@RunWith(AndroidJUnit4::class)
class Release12FlowTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val instrument get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrument.targetContext
    private lateinit var scenario: ActivityScenario<MainActivity>
    private fun waitState(check: (Ledger.Snapshot) -> Boolean): Ledger.Snapshot {
        var result: Ledger.Snapshot? = null
        var lastError: String? = null
        compose.waitUntil(90000) {
            scenario.onActivity {
                val state = ViewModelProvider(it)[CashBookViewModel::class.java].state.value
                lastError = state.error
                if (!state.busy && state.error == null && state.snapshot?.let(check) == true) result = state.snapshot
            }
            result != null
        }
        assertNull(lastError); return result!!
    }
    private fun SemanticsNodeInteraction.replaceValue(value:String)=performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.SetText){it(androidx.compose.ui.text.AnnotatedString(value))}
    private fun step(text: String) {
        instrument.sendStatus(2, android.os.Bundle().apply { putString("stream", "\nSTEP: $text\n") })
    }
    private fun hideKeyboard() {
        val info = instrument.uiAutomation.serviceInfo
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        instrument.uiAutomation.serviceInfo = info
        if (instrument.uiAutomation.windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            instrument.uiAutomation.waitForIdle(750, 15000)
        }
    }
    private fun dismissSystemDialog() {
        val root = instrument.uiAutomation.rootInActiveWindow ?: return
        if (root.packageName?.toString() !in listOf("android", "com.android.systemui")) return
        if (root.findAccessibilityNodeInfosByText("System UI").isEmpty()) return
        var button = root.findAccessibilityNodeInfosByText("Wait").firstOrNull() ?: return
        while (!button.isClickable && button.parent != null) button = button.parent
        button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        instrument.uiAutomation.waitForIdle(750, 15000)
    }
    private fun capture(name: String) {
        dismissSystemDialog(); hideKeyboard(); compose.waitForIdle(); instrument.uiAutomation.waitForIdle(750, 15000)
        val dir = File(context.getExternalFilesDir(null), "release12-screenshots").apply { mkdirs() }
        val bytes = ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("screencap -p")).use { it.readBytes() }
        assertTrue(bytes.size > 8 && bytes[0] == 0x89.toByte()); File(dir,name).writeBytes(bytes)
    }
    private fun picker() {
        hideKeyboard(); dismissSystemDialog()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isEmpty()) compose.onNodeWithTag("account_picker_open").performClick()
    }
    private fun closePicker() {
        hideKeyboard()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isNotEmpty()) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            compose.waitForIdle()
        }
    }
    private fun select(id:String){picker();compose.onNodeWithTag("accounts_list").performScrollToNode(hasTestTag("account_row_$id"));compose.onNodeWithTag("account_row_$id").performClick()}
    private fun due(index:Int){compose.onNodeWithTag("debt_tab_schedule").performClick();compose.onNodeWithTag("debt_schedule").performScrollToNode(hasTestTag("due_$index"));compose.onNodeWithTag("due_$index").performClick()}
    private fun payment(id:String){compose.onNodeWithTag("debt_tab_payments").performClick();compose.onNodeWithTag("debt_payments").performScrollToNode(hasTestTag("payment_$id"));compose.onNodeWithTag("payment_$id").performClick()}
    private fun shell(command:String)=ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand(command)).use{it.readBytes()}
    private fun raw(name:String){compose.waitForIdle();instrument.uiAutomation.waitForIdle(750,15000);val dir=File(context.getExternalFilesDir(null),"release12-screenshots").apply{mkdirs()};File(dir,name).writeBytes(shell("screencap -p"))}
    private fun cancelDraft(){hideKeyboard();compose.waitForIdle();val label=if(com.todoshift.cashbook.ui.CashBookText.arabic())"إلغاء" else "Cancel";compose.onNodeWithText(label).performClick();compose.waitUntil(15000){compose.onAllNodesWithText(if(com.todoshift.cashbook.ui.CashBookText.arabic())"تجاهل" else "Discard").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithText(if(com.todoshift.cashbook.ui.CashBookText.arabic())"تجاهل" else "Discard").performClick()}
    private fun focusNumeric(){
        fun all(node:AccessibilityNodeInfo?):List<AccessibilityNodeInfo>{if(node==null)return emptyList();return listOf(node)+(0 until node.childCount).flatMap{all(node.getChild(it))}}
        val field=all(instrument.uiAutomation.rootInActiveWindow).first{it.isEditable&&(it.inputType and android.text.InputType.TYPE_MASK_CLASS)==android.text.InputType.TYPE_CLASS_NUMBER}
        val bounds=android.graphics.Rect();field.getBoundsInScreen(bounds);shell("settings put secure show_ime_with_hard_keyboard 1");shell("input tap ${bounds.centerX()} ${bounds.centerY()}");compose.waitUntil(20000){instrument.uiAutomation.windows.any{it.type==AccessibilityWindowInfo.TYPE_INPUT_METHOD}};instrument.uiAutomation.waitForIdle(1500,15000)
    }
    private fun assertNumeric(signed:Boolean=false){
        fun all(node:AccessibilityNodeInfo?):List<AccessibilityNodeInfo>{if(node==null)return emptyList();return listOf(node)+(0 until node.childCount).flatMap{all(node.getChild(it))}}
        val fields=all(instrument.uiAutomation.rootInActiveWindow).filter{it.isEditable&&(it.inputType and android.text.InputType.TYPE_MASK_CLASS)==android.text.InputType.TYPE_CLASS_NUMBER}
        assertTrue("Numeric native field missing",fields.isNotEmpty());if(signed)assertTrue(fields.any{it.inputType and android.text.InputType.TYPE_NUMBER_FLAG_SIGNED!=0})
        assertTrue(fields.all{it.inputType and android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL==0})
    }
    @Test fun paymentsAndLegacy(){
        val original=Ledger(AndroidLedgerStore(context)).load();assertEquals(5050L,original.entries.single().minor);assertEquals(7295L,original.balance("old"));assertEquals(30050L,original.debts.single().principal(original))
        context.getSharedPreferences("cashbook-language",0).edit().putString("language","ar").commit()
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use{
            waitState{it.debts.size==1};select("legacy-debt");compose.onNodeWithTag("debt_progress").assertExists();capture("schedule-ar.png")
            payment("old-payment");compose.onNodeWithTag("payment_edit").performClick();compose.onNodeWithTag("payment_link").performClick();compose.onNodeWithTag("payment_amount").replaceValue("60");compose.onNodeWithTag("payment_save").performClick()
            waitState{it.balance("old")==12345L&&it.entries.single().kind==Ledger.Kind.SETTLEMENT};step("legacy values retained, linked payment changed atomically to unlinked")
            payment("old-payment");compose.onNodeWithTag("payment_delete").performClick();compose.onNodeWithTag("payment_delete_confirm").performClick();waitState{it.entries.single().deleted};compose.onNodeWithTag("undo_delete").performClick();waitState{!it.entries.single().deleted}
            due(0);compose.onNodeWithTag("due_pay_now").performClick();compose.onAllNodesWithTag("payment_account").assertCountEquals(0);compose.onNodeWithTag("payment_save").performClick();waitState{it.debts.single().remaining(it)==20050L}
            compose.onNodeWithTag("debt_pay").performClick();compose.onNodeWithTag("payment_amount").replaceValue("200");compose.onNodeWithTag("payment_save").performClick();waitState{it.debts.single().remaining(it)==50L}
            compose.onNodeWithTag("debt_pay").performClick();compose.onNodeWithTag("legacy_full").performClick();compose.onNodeWithTag("payment_save").performClick();waitState{it.debts.single().remaining(it)==0L};assertEquals(12345L,waitState{true}.balance("old"))
            step("Pay Now and exact legacy fractional settlement passed")
            picker();compose.onNodeWithTag("accounts_add").performClick();compose.onNodeWithTag("create_debt_open").performScrollTo().performClick();compose.onNodeWithTag("debt_name").replaceValue("دين جديد");compose.onNodeWithTag("debt_total").replaceValue("500");compose.onNodeWithTag("debt_frequency").performScrollTo().performClick();compose.onNodeWithTag("frequency_MONTHLY").performClick();compose.onNodeWithTag("debt_installment").performScrollTo().replaceValue("100");hideKeyboard();compose.onNodeWithTag("debt_save").performClick()
            val id=waitState{it.debts.size==2}.debts.last().accountId;select(id);due(1);compose.onNodeWithTag("due_pay_now").performClick();compose.onNodeWithTag("payment_amount").replaceValue("١٥٠");compose.onNodeWithTag("early_credit").performScrollTo().performClick();compose.onNodeWithTag("payment_save").performClick();waitState{it.debts.last().advanceCredit(it)==5000L}
            compose.onNodeWithTag("debt_pay").performClick();compose.onNodeWithTag("payment_amount").replaceValue("150");compose.onNodeWithTag("payment_save").performClick();compose.onNodeWithTag("duplicate_continue").performClick();waitState{it.debts.last().remaining(it)==20000L}
            compose.onNodeWithTag("debt_pay").performClick();compose.onNodeWithTag("payment_amount").replaceValue("100");compose.onNodeWithTag("payment_link").performClick();compose.onNodeWithTag("payment_account").performClick();compose.onNodeWithText("محفظة قديمة").performClick();compose.onNodeWithTag("payment_save").performClick()
            val end=waitState{it.debts.last().remaining(it)==10000L};assertEquals(2345L,end.balance("old"));assertEquals(0L,end.total(Ledger.Kind.INCOME));assertEquals(0L,end.total(Ledger.Kind.EXPENSE));assertEquals(5000L,end.debts.last().advanceCredit(end))
            compose.onNodeWithTag("debt_tab_payments").performClick();capture("payments-ar.png");compose.onNodeWithTag("debt_tab_schedule").performClick();capture("new-schedule-ar.png");File(context.noBackupFilesDir,"release12-pid.txt").writeText(android.os.Process.myPid().toString());step("unlinked, linked, targeted, early credit, duplicate warning and undo passed")
        }
    }
    @Test fun languageDraftKeyboard(){
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use{
            scenario.onActivity{com.todoshift.cashbook.ui.CashBookText.select("ar");ViewModelProvider(it)[CashBookViewModel::class.java].reload()};val snapshot=waitState{it.debts.size==2};select(snapshot.debts.last().accountId);compose.onNodeWithTag("debt_pay").performClick();compose.onNodeWithTag("payment_amount").performClick();compose.onNodeWithTag("payment_amount").replaceValue("37");focusNumeric();assertNumeric();compose.onNodeWithTag("payment_save").assertIsDisplayed();raw("numeric-ar.png")
            val before=AndroidLedgerStore(context).read();val ar=compose.onNodeWithTag("payment_save").getUnclippedBoundsInRoot()
            scenario.onActivity{com.todoshift.cashbook.ui.CashBookText.select("en");ViewModelProvider(it)[CashBookViewModel::class.java].reload()};waitState{true}
            compose.onNodeWithText("Save payment").assertExists();compose.onNodeWithTag("payment_amount").assertTextContains("37");val en=compose.onNodeWithTag("payment_save").getUnclippedBoundsInRoot();assertEquals(ar.left.value,en.left.value,2f);assertEquals(ar.right.value,en.right.value,2f);assertArrayEquals(before,AndroidLedgerStore(context).read());focusNumeric();assertNumeric();compose.onNodeWithTag("payment_save").assertIsDisplayed();raw("numeric-en.png")
            hideKeyboard();compose.onNodeWithTag("day_picker").performClick();instrument.uiAutomation.waitForIdle(750,15000);val cancel=instrument.uiAutomation.rootInActiveWindow.findAccessibilityNodeInfosByViewId("android:id/button2").first();assertTrue(cancel.text.toString().lowercase().contains("cancel"));cancel.performAction(AccessibilityNodeInfo.ACTION_CLICK);instrument.uiAutomation.waitForIdle(750,15000)
            cancelDraft();compose.onNodeWithText("Installments").assertExists();capture("schedule-en.png")
            compose.onNodeWithTag("section_options").performClick();compose.onNodeWithTag("default_settings_open").performClick();compose.onNodeWithText("Language").performClick();compose.onNodeWithTag("language_ar").performClick();waitState{true};compose.onAllNodesWithText("اللغة / Language").onLast().assertExists();compose.onNodeWithText("تم").performClick();compose.onNodeWithText("إغلاق").performClick()
            picker();compose.onNodeWithTag("accounts_add").performClick();compose.onNodeWithTag("account_opening").performClick();compose.onNodeWithTag("account_opening").replaceValue("-50");focusNumeric();assertNumeric(true);raw("signed-opening.png");cancelDraft()
            scenario.onActivity{com.todoshift.cashbook.ui.CashBookText.select("en");ViewModelProvider(it)[CashBookViewModel::class.java].reload()};waitState{true};step("language change preserved draft and bytes; fixed button bounds; numeric and signed keyboards passed")
        }
    }
    @Test fun backupAndReminders(){
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use{
            var snapshot=waitState{it.debts.size==2};val backup=Ledger(AndroidLedgerStore(context)).apply{load()}.backup()
            val isolated=object:android.content.ContextWrapper(context){override fun getNoBackupFilesDir()=File(context.cacheDir,"release12-restore").apply{mkdirs()}};isolated.noBackupFilesDir.listFiles()?.forEach{it.delete()};val restored=Ledger(AndroidLedgerStore(isolated));restored.load();restored.restore(backup);restored.restore(backup);assertEquals(snapshot.entries.size,restored.snapshot().entries.size);assertArrayEquals(backup,restored.backup());assertEquals(5000L,restored.snapshot().debts.last().advanceCredit(restored.snapshot()))
            val manager=context.getSystemService(android.app.NotificationManager::class.java)
            for(lang in listOf("en","ar")){
                scenario.onActivity{com.todoshift.cashbook.ui.CashBookText.select(lang);ViewModelProvider(it)[CashBookViewModel::class.java].reload()};waitState{true};val count=snapshot.debts.size;val today=java.time.LocalDate.now()
                scenario.onActivity{ViewModelProvider(it)[CashBookViewModel::class.java].debt("Reminder $lang","10",today.minusDays(3).toString(),"",com.todoshift.cashbook.core.Debt("",com.todoshift.cashbook.core.Debt.Direction.PAYABLE,com.todoshift.cashbook.core.Debt.Frequency.OPEN,0,today.minusDays(1).toString(),emptyList(),true,1,"00:00",emptyList())){}}
                snapshot=waitState{it.debts.size==count+1};val id=snapshot.debts.last().accountId;compose.waitUntil(150000){manager.activeNotifications.any{it.tag==id}};val message=manager.activeNotifications.first{it.tag==id}.notification.extras.getCharSequence(android.app.Notification.EXTRA_TEXT).toString();assertTrue(message,if(lang=="en")message.contains("Overdue") else message.contains("قسط متأخر"))
                val posted=manager.activeNotifications.first{it.tag==id}.postTime;scenario.onActivity{ViewModelProvider(it)[CashBookViewModel::class.java].reload()};waitState{true};assertEquals(posted,manager.activeNotifications.first{it.tag==id}.postTime)
                scenario.onActivity{ViewModelProvider(it)[CashBookViewModel::class.java].settle(id,"","10",today.toString(),"10:00","",null){}};snapshot=waitState{it.debts.last().remaining(it)==0L};compose.waitUntil(30000){manager.activeNotifications.none{it.tag==id}}
            }
            scenario.onActivity{com.todoshift.cashbook.ui.CashBookText.select("en");ViewModelProvider(it)[CashBookViewModel::class.java].reload()};waitState{true};step("backup restore twice without duplicates; real Arabic and English notifications delivered, not repeated, cancelled after payment")
        }
    }
    @Test fun restartAndSmallScreen(){
        val oldPid=File(context.noBackupFilesDir,"release12-pid.txt").readText().trim().toInt();assertNotEquals(oldPid,android.os.Process.myPid());val snapshot=Ledger(AndroidLedgerStore(context)).load();assertEquals(2345L,snapshot.balance("old"));assertEquals(0L,snapshot.debts.first().remaining(snapshot));val debt=snapshot.debts.first{it.account(snapshot).name=="دين جديد"};assertEquals(10000L,debt.remaining(snapshot));assertEquals(5000L,debt.advanceCredit(snapshot));android.util.Log.i("Release12FlowTest","Restart verified: old PID=$oldPid new PID=${android.os.Process.myPid()}")
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use{
            scenario.onActivity{com.todoshift.cashbook.ui.CashBookText.select("en");ViewModelProvider(it)[CashBookViewModel::class.java].reload()};waitState{it.debts.size>=2};select(debt.accountId);shell("wm size 480x960");shell("settings put system font_scale 1.15");compose.waitForIdle();waitState{true};compose.onNodeWithTag("debt_progress").assertIsDisplayed();compose.onNodeWithTag("debt_tab_schedule").assertIsDisplayed();capture("small-en.png")
            compose.onNodeWithTag("debt_pay").performClick();compose.onNodeWithTag("payment_amount").performClick();compose.onNodeWithTag("payment_amount").replaceValue("11");compose.onNodeWithTag("payment_save").assertIsDisplayed();focusNumeric();assertNumeric();compose.onNodeWithTag("payment_save").assertIsDisplayed();raw("small-keyboard-en.png");cancelDraft()
            scenario.onActivity{com.todoshift.cashbook.ui.CashBookText.select("ar");ViewModelProvider(it)[CashBookViewModel::class.java].reload()};waitState{true};compose.onNodeWithTag("debt_tab_schedule").assertIsDisplayed();compose.onNodeWithTag("debt_schedule").performScrollToNode(hasTestTag("due_0"));compose.onNodeWithTag("due_0").assertIsDisplayed();instrument.uiAutomation.waitForIdle(1500,15000);capture("small-ar.png");shell("wm size reset");shell("settings put system font_scale 1.0")
            step("restart and 320dp small-screen layouts in both languages passed")
        }
    }
}
