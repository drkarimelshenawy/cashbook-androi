package com.todoshift.cashbook.sandbox

import android.accessibilityservice.AccessibilityServiceInfo
import android.os.ParcelFileDescriptor
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.todoshift.cashbook.core.Ledger
import com.todoshift.cashbook.ui.AndroidLedgerStore
import com.todoshift.cashbook.ui.CashBookViewModel
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Disposable emulator only. Harness seeds v3 data and installs 0.9 OVER 0.8 before phase one. */
@RunWith(AndroidJUnit4::class)
class DebtFlowTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val instrument get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrument.targetContext
    private lateinit var scenario: ActivityScenario<MainActivity>
    private fun waitState(check: (Ledger.Snapshot) -> Boolean): Ledger.Snapshot {
        var result: Ledger.Snapshot? = null
        var lastError: String? = null
        compose.waitUntil(90000) {
            scenario.onActivity {
                val state = ViewModelProvider(it)[CashBookViewModel::class.java].state.value
                lastError = state.error
                if (!state.busy && state.error == null && state.snapshot?.let(check) == true) result = state.snapshot
            }
            result != null
        }
        assertNull(lastError); return result!!
    }
    private fun step(text: String) {
        instrument.sendStatus(2, android.os.Bundle().apply { putString("stream", "\nSTEP: $text\n") })
    }
    private fun hideKeyboard() {
        val info = instrument.uiAutomation.serviceInfo
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        instrument.uiAutomation.serviceInfo = info
        if (instrument.uiAutomation.windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            instrument.uiAutomation.waitForIdle(750, 15000)
        }
    }
    private fun dismissSystemDialog() {
        val root = instrument.uiAutomation.rootInActiveWindow ?: return
        if (root.packageName?.toString() !in listOf("android", "com.android.systemui")) return
        if (root.findAccessibilityNodeInfosByText("System UI").isEmpty()) return
        var button = root.findAccessibilityNodeInfosByText("Wait").firstOrNull() ?: return
        while (!button.isClickable && button.parent != null) button = button.parent
        button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        instrument.uiAutomation.waitForIdle(750, 15000)
    }
    private fun capture(name: String) {
        dismissSystemDialog(); hideKeyboard(); compose.waitForIdle(); instrument.uiAutomation.waitForIdle(750, 15000)
        val dir = File(context.getExternalFilesDir(null), "debt-screenshots").apply { mkdirs() }
        val bytes = ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("screencap -p")).use { it.readBytes() }
        assertTrue(bytes.size > 8 && bytes[0] == 0x89.toByte()); File(dir,name).writeBytes(bytes)
    }
    private fun picker() {
        hideKeyboard(); dismissSystemDialog()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isEmpty()) compose.onNodeWithTag("account_picker_open").performClick()
    }
    private fun closePicker() {
        hideKeyboard()
        if (compose.onAllNodesWithTag("accounts_dialog").fetchSemanticsNodes().isNotEmpty()) {
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            compose.waitForIdle()
        }
    }
    private fun select(id:String){picker();compose.onNodeWithTag("accounts_list").performScrollToNode(hasTestTag("account_row_$id"));compose.onNodeWithTag("account_row_$id").performClick()}
    private fun createDebt(name:String,total:String,monthly:Boolean,receivable:Boolean=false):String {
        picker();compose.onNodeWithTag("accounts_add").performClick();compose.onNodeWithTag("create_debt_open").performScrollTo().performClick()
        compose.onNodeWithTag("debt_name").performTextReplacement(name)
        compose.onNodeWithTag("debt_total").performTextReplacement(total)
        if(receivable){hideKeyboard();compose.onNodeWithTag("debt_receivable").performScrollTo().performClick()}
        if(monthly){hideKeyboard();compose.onNodeWithTag("debt_frequency").performScrollTo().performClick();compose.onNodeWithTag("frequency_MONTHLY").performClick();compose.onNodeWithTag("debt_installment").performScrollTo().performTextReplacement("100")}
        hideKeyboard();capture("debt-create.png");compose.onNodeWithTag("debt_save").performClick()
        return waitState{it.accounts.any{a->a.name==name}}.accounts.first{it.name==name}.id
    }
    private fun clickInDebt(tag:String){compose.onNodeWithTag("debt_panel").performScrollToNode(hasTestTag(tag));compose.onNodeWithTag(tag).performClick()}
    @Test fun debtFlow(){
        val old=Ledger(AndroidLedgerStore(context)).load();assertEquals(12345L,old.balance("old"));assertEquals("💳",old.accounts.first().icon)
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use{
            waitState{it.accounts.size==1};step("v5 legacy loaded; choosing vector icon")
            picker();compose.onNodeWithTag("accounts_edit").performClick();compose.onNodeWithTag("account_row_old").performClick();compose.onNodeWithText("تعديل الحساب").performClick()
            compose.onNodeWithTag("account_icon_picker").performClick();compose.onNodeWithTag("icon_search").performTextReplacement("سياره");hideKeyboard()
            val car=com.todoshift.cashbook.core.AccountIconCatalog.ALL.first{it.name=="car"}.id
            compose.onNodeWithTag("favorite_$car").performClick();waitState{it.preferences.favorites.contains(car)}
            capture("icon-search.png");compose.onNodeWithTag("icon_$car").performClick();waitState{it.preferences.recent.firstOrNull()==car}
            compose.onNodeWithTag("account_details_save").performClick();waitState{it.accounts.first().icon==car};closePicker()
            val a=createDebt("أقساط جهاز","300",true);select(a);step("monthly debt created")
            compose.onNodeWithTag("debt_remaining").assertTextEquals("300.00")
            capture("debt-overview.png");clickInDebt("debt_pay")
            compose.onNodeWithTag("payment_amount").performTextReplacement("50");hideKeyboard();compose.onNodeWithTag("payment_save").performClick()
            var snap=waitState{it.debts.first().remaining(it)==25000L};val pay=snap.entries.single().id
            assertEquals(7345L,snap.balance("old"));assertEquals(0L,snap.total(Ledger.Kind.EXPENSE));assertEquals(0L,snap.total(Ledger.Kind.INCOME))
            clickInDebt("edit_payment_$pay");compose.onNodeWithTag("payment_amount").performTextReplacement("60");hideKeyboard();compose.onNodeWithTag("payment_save").performClick()
            waitState{it.debts.first().remaining(it)==24000L}
            clickInDebt("delete_payment_$pay");waitState{it.debts.first().remaining(it)==30000L}
            clickInDebt("delete_payment_$pay");waitState{it.debts.first().remaining(it)==24000L}
            clickInDebt("postpone_1");compose.onNodeWithTag("postpone_save").performClick();waitState{it.debts.first().changes.size==1}
            compose.onNodeWithTag("debt_panel").performScrollToIndex(0);capture("debt-after-payment.png");step("partial/edit/delete/restore/postpone passed")
            val rec=createDebt("فلوس لي","90",false,true);select(rec);clickInDebt("debt_pay");compose.onNodeWithTag("payment_amount").performTextReplacement("30");hideKeyboard();compose.onNodeWithTag("payment_save").performClick()
            snap=waitState{it.debts.last().remaining(it)==6000L};assertEquals(9345L,snap.balance("old"));assertEquals(0L,snap.total(Ledger.Kind.EXPENSE));assertEquals(0L,snap.total(Ledger.Kind.INCOME));capture("receivable.png")
            File(context.noBackupFilesDir,"debt-test-pid.txt").writeText(android.os.Process.myPid().toString());step("receivable transfer and all debt UI assertions passed")
        }
    }
    @Test fun restart(){
        val previous=File(context.noBackupFilesDir,"debt-test-pid.txt").readText().trim().toInt();assertNotEquals(previous,android.os.Process.myPid())
        val snap=Ledger(AndroidLedgerStore(context)).load();assertEquals(2,snap.debts.size);assertEquals(24000L,snap.debts.first().remaining(snap));assertEquals(6000L,snap.debts.last().remaining(snap));assertEquals(1,snap.debts.first().changes.size);assertEquals(9345L,snap.balance("old"));assertTrue(snap.accounts.first().icon.startsWith("i:"));assertTrue(snap.preferences.favorites.contains(snap.accounts.first().icon))
        android.util.Log.i("DebtFlowTest","Restart verified: old PID=$previous new PID=${android.os.Process.myPid()}")
        scenario=ActivityScenario.launch(MainActivity::class.java);scenario.use{waitState{it.debts.size==2};select(snap.debts.first().accountId);compose.onNodeWithTag("debt_remaining").assertTextEquals("240.00");capture("after-restart.png")}
    }
    @Test fun notificationDelivery(){
        scenario=ActivityScenario.launch(MainActivity::class.java)
        scenario.use{
            waitState{it.debts.size==2};val now=java.time.LocalDate.now();val due=now.minusDays(1)
            scenario.onActivity{val vm=ViewModelProvider(it)[CashBookViewModel::class.java];vm.debt("تنبيه اختبار","10",now.minusDays(3).toString(),"",com.todoshift.cashbook.core.Debt("",com.todoshift.cashbook.core.Debt.Direction.PAYABLE,com.todoshift.cashbook.core.Debt.Frequency.OPEN,0,due.toString(),emptyList(),true,1,"00:00",emptyList())){}}
            val snap=waitState{it.debts.size==3};val id=snap.debts.last().accountId
            val manager=context.getSystemService(android.app.NotificationManager::class.java)
            compose.waitUntil(150000){manager.activeNotifications.any{it.tag==id}}
            assertEquals("تنبيه اختبار",manager.activeNotifications.first{it.tag==id}.notification.extras.getString(android.app.Notification.EXTRA_TITLE))
            val open=manager.activeNotifications.first{it.tag==id}.notification.contentIntent;assertEquals(context.packageName,open.creatorPackage)
            scenario.onActivity{ViewModelProvider(it)[CashBookViewModel::class.java].settle(id,"old","10",now.toString(),"10:00","سداد كامل",null){}}
            waitState{it.debts.last().remaining(it)==0L};compose.waitUntil(30000){manager.activeNotifications.none{it.tag==id}}
            step("real overdue notification delivered; cancelled after full settlement")
        }
    }
    @Test fun atomicConcurrentReader(){
        val isolated=object:android.content.ContextWrapper(context){override fun getNoBackupFilesDir()=File(context.cacheDir,"atomic-read-write-test").apply{mkdirs()}}
        isolated.noBackupFilesDir.listFiles()?.forEach{it.delete()}
        val writer=Ledger(AndroidLedgerStore(isolated));writer.load();val id=writer.addAccount("اختبار","EGP",10000)
        val errors=java.util.concurrent.ConcurrentLinkedQueue<Throwable>();val start=java.util.concurrent.CountDownLatch(1)
        val threads=(0..2).map{index->Thread{
            try{start.await();repeat(50){if(index==0)writer.post(Ledger.Kind.INCOME,id,null,1,"","2026-11-12")else{val snapshot=Ledger(AndroidLedgerStore(isolated)).load();assertEquals(10000L+snapshot.entries.size,snapshot.balance(id))}}}catch(t:Throwable){errors.add(t)}
        }.apply{start()}}
        start.countDown();threads.forEach{it.join(60000);assertFalse(it.isAlive)}
        assertTrue(errors.joinToString("\n"),errors.isEmpty());assertEquals(10050L,Ledger(AndroidLedgerStore(isolated)).load().balance(id))
        step("50 atomic writes and 100 concurrent validated reads passed")
    }

}
