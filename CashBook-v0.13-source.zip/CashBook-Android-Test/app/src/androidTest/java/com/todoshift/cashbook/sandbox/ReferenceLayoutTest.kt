package com.todoshift.cashbook.sandbox

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.todoshift.cashbook.core.Ledger
import com.todoshift.cashbook.ui.AndroidLedgerStore
import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Disposable emulator fixture only. Never run against a user's installation. */
@RunWith(AndroidJUnit4::class)
class ReferenceLayoutTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val instrument get() = InstrumentationRegistry.getInstrumentation()
    private fun dismissEmulatorSystemDialog() {
        val root = instrument.uiAutomation.rootInActiveWindow ?: return
        if (root.packageName?.toString() !in listOf("android", "com.android.systemui")) return
        if (root.findAccessibilityNodeInfosByText("System UI").isEmpty()) return
        var wait = root.findAccessibilityNodeInfosByText("Wait").firstOrNull() ?: return
        while (!wait.isClickable && wait.parent != null) wait = wait.parent
        if (wait.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)) {
            android.util.Log.w("ReferenceLayoutTest", "Dismissed emulator System UI ANR dialog with Wait")
            instrument.waitForIdleSync()
        }
    }
    private fun capture(name: String) {
        dismissEmulatorSystemDialog()
        compose.waitForIdle()
        instrument.uiAutomation.waitForIdle(750, 15000)
        val target = File(instrument.targetContext.getExternalFilesDir(null), "screenshots").apply { mkdirs() }
        val pixels = android.os.ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("screencap -p")).use { it.readBytes() }
        assertTrue("Native screencap must return PNG", pixels.size > 8 && pixels[0] == 0x89.toByte() && pixels[1] == 'P'.code.toByte())
        File(target, name).writeBytes(pixels)
        if (name == "entry-keyboard.png") {
            val diagnostics = android.os.ParcelFileDescriptor.AutoCloseInputStream(instrument.uiAutomation.executeShellCommand("dumpsys input_method")).use { it.readBytes() }
            File(target, "ime.txt").writeBytes(diagnostics)
        }
    }
    @Test fun referenceScreensAndImeContainment() {
        val context = instrument.targetContext
        context.noBackupFilesDir.listFiles()?.forEach { it.delete() }
        val ledger = Ledger(AndroidLedgerStore(context)); ledger.load()
        val cash = ledger.addAccount("نقدي", "EGP", 100000)
        val bank = ledger.addAccount("Bank", "EGP", 0)
        repeat(12) { ledger.addAccount("حساب ${it + 1}", "EGP", 0) }
        ledger.post(Ledger.Kind.EXPENSE, cash, null, 400000, "مشتريات", "2026-11-10", "14:17")
        ledger.post(Ledger.Kind.EXPENSE, cash, null, 5000, "مواصلات", "2026-11-09", "15:51")
        ledger.post(Ledger.Kind.EXPENSE, cash, null, 800000, "مستلزمات البيت", "2026-11-08", "16:08")
        ledger.post(Ledger.Kind.EXPENSE, cash, null, 150000, "صيانة", "2026-11-07", "18:57")
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            compose.waitUntil(45000) { compose.onAllNodesWithTag("period_caption").fetchSemanticsNodes().isNotEmpty() }
            val caption = compose.onNodeWithTag("period_caption").getUnclippedBoundsInRoot()
            assertTrue("Caption must stay compact", (caption.bottom.value - caption.top.value) in 28f..32f)
            capture("movement.png")
            compose.onNodeWithTag("account_picker_open").performClick()
            compose.onNodeWithTag("accounts_add").assertIsDisplayed()
            capture("accounts.png")
            compose.onNodeWithTag("accounts_search").performTextInput("Bank")
            compose.onNodeWithTag("account_row_$bank").assertIsDisplayed()
            compose.onNodeWithTag("accounts_search").performTextClearance()
            // Clearing a filter retains the lazy list's scroll position; scroll to the target row.
            compose.onNodeWithTag("accounts_list").performScrollToNode(hasTestTag("account_row_$cash"))
            // Select the existing cash account and close the picker.
            compose.onNodeWithTag("account_row_$cash").performClick()
            compose.onNodeWithTag("quick_expense").performClick()
            compose.waitUntil(45000) {
                var visible = false
                scenario.onActivity { visible = ViewCompat.getRootWindowInsets(it.window.decorView)?.isVisible(WindowInsetsCompat.Type.ime()) == true }
                visible
            }
            compose.onNodeWithTag("save_exit").assertIsDisplayed()
            val viewport = compose.onNodeWithTag("editor_viewport").getUnclippedBoundsInRoot()
            val save = compose.onNodeWithTag("editor_save_bar").getUnclippedBoundsInRoot()
            assertTrue("Save bar stays inside IME-resized viewport", save.bottom <= viewport.bottom && save.top >= viewport.top)
            var keyboardTopPx = 0
            scenario.onActivity {
                val ime = ViewCompat.getRootWindowInsets(it.window.decorView)!!.getInsets(WindowInsetsCompat.Type.ime()).bottom
                keyboardTopPx = it.window.decorView.height - ime
            }
            val saveWindow = compose.onNodeWithTag("editor_save_bar").fetchSemanticsNode().boundsInWindow
            assertTrue("Save bar must be above the actual keyboard", saveWindow.bottom <= keyboardTopPx + 2f)
            capture("entry-keyboard.png")
            instrument.uiAutomation.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            compose.waitUntil(45000) {
                var hidden = false
                scenario.onActivity { hidden = ViewCompat.getRootWindowInsets(it.window.decorView)?.isVisible(WindowInsetsCompat.Type.ime()) != true }
                hidden
            }
            compose.waitForIdle()
            capture("entry.png")
            // Grouped display must never leak into the editable money parser.
            compose.onNodeWithTag("entry_amount").performTextInput("1234.50")
            compose.onNodeWithTag("entry_note").performTextInput("اختبار التنسيق")
            compose.onNodeWithTag("save_exit").performClick()
            compose.waitUntil(45000) { compose.onAllNodesWithText("1,234.5").fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithText("1,234.5").performClick()
            compose.onNodeWithText("عرض / تعديل").performClick()
            compose.onNodeWithTag("entry_amount").assertTextEquals("1234.50")
        }
    }
}
