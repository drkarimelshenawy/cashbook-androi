package com.todoshift.cashbook.sandbox

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Run on a clean disposable installation; never against production data. */
@RunWith(AndroidJUnit4::class)
class CashBookSmokeTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    @Test fun createAccountPostExpenseAndRecreate() {
        compose.onNodeWithText("إضافة أول حساب").performClick()
        compose.onNodeWithTag("account_name").performTextInput("اختبار")
        compose.onNodeWithTag("account_opening").performTextInput("1000")
        compose.onNodeWithText("حفظ", useUnmergedTree = true).performClick()
        compose.waitUntil(timeoutMillis = 10_000) { compose.onAllNodesWithTag("total_balance").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("total_balance").assertTextEquals("1000.00")
        compose.onNodeWithTag("quick_expense").performClick()
        compose.onNodeWithTag("entry_amount").performTextInput("25.50")
        compose.onNodeWithTag("entry_note").performTextInput("مواصلات")
        compose.onNodeWithTag("save_exit").performClick()
        compose.waitUntil(timeoutMillis = 10_000) { compose.onAllNodesWithTag("save_exit").fetchSemanticsNodes().isEmpty() }
        compose.onNodeWithTag("total_balance").assertTextEquals("974.50")
        compose.activityRule.scenario.recreate()
        compose.onNodeWithTag("total_balance").assertTextEquals("974.50")
    }
}
