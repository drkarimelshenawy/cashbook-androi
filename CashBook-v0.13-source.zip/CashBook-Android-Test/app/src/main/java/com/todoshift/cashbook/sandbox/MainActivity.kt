package com.todoshift.cashbook.sandbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.compose.foundation.background
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.todoshift.cashbook.ui.CashBookRoute
import com.todoshift.cashbook.ui.CashBookViewModel

/** Disposable test host only. All financial behavior stays in cashbook-feature/core. */
class MainActivity : ComponentActivity() {
    private val cashBook by viewModels<CashBookViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cashBook.openDebt(intent.getStringExtra(com.todoshift.cashbook.ui.AndroidDebtReminderHost.OPEN_DEBT))
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT))
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF2196E8), onPrimary = Color.White,
                primaryContainer = Color(0xFF2196E8), onPrimaryContainer = Color.White,
                surface = Color.White, onSurface = Color(0xFF222222), surfaceVariant = Color(0xFFEEF2F4)
            )) {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize()) {
                        Spacer(Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).background(MaterialTheme.colorScheme.primary))
                        Box(Modifier.weight(1f).fillMaxWidth().consumeWindowInsets(WindowInsets.statusBars).navigationBarsPadding().imePadding()) {
                            CashBookRoute(vm = cashBook)
                        }
                    }
                }
            }
        }
    }
    override fun onNewIntent(intent:android.content.Intent){super.onNewIntent(intent);setIntent(intent);cashBook.openDebt(intent.getStringExtra(com.todoshift.cashbook.ui.AndroidDebtReminderHost.OPEN_DEBT))}

}
