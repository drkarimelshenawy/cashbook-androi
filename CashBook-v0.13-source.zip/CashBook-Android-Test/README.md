# Cash Book 0.13.0-test

أضيف التقسيم الثابت للحسابات والمديونية ومستحقات العمل، مع إبقاء مستحقات العمل فارغة للربط لاحقًا بمصدر بيانات ToDo Shift. راجع `IMPLEMENTATION_13.md` للتفاصيل.

# Cash Book 0.12.0-test

واجهة المديونية المصغرة، سداد اختياري الارتباط بحساب، موارد عربية وإنجليزية مع ترتيب ثابت، وإدخال مبالغ صحيحة مع حفظ دقة القيم القديمة. راجع RELEASE_12.md وRELEASE_QA_12.md للتحقق والقيود. تطبيق اختبار مستقل قابل للدمج؛ لم يتم دمجه في ToDo Shift.

# Cash Book 0.11.0-test

المتطلبات المنفذة الحالية: DEBT_AND_ICONS_11.md. التحقق الحالي: DEBT_QA_11.md وBUILD_STATUS.md. الوحدتان مستقلتان عن ToDo Shift؛ توصيل نظام تنبيهاته الموحد خطوة دمج لاحقة.

# Cash Book 0.10.0-test

راجع COMPACT_ACCOUNTS_10.md لنطاق الواجهة والإدارة، وCOMPACT_QA_10.md للتحقق الحالي.

# Cash Book Android Test — 0.9.0-test

مشروع Android تجريبي مؤقت يشغّل قسم Cash Book بالتصميم المصغّر المعتمد، تمهيدًا لدمجه في ToDo Shift.

## التقسيم

- `app`: غلاف اختبار فقط، بمعرّف `com.todoshift.cashbook.sandbox` واسم **Cash Book Test**. لا يستخدم معرّف ToDo Shift أو ملفاته.
- `cashbook-feature`: واجهة Kotlin/Jetpack Compose والتخزين المحلي وViewModel. نقطة الدخول `CashBookRoute`، والكثافة المصغّرة داخل `CashBookCompactTheme`.
- `cashbook-core`: منطق الأموال والتحويلات والبنود والاستعادة والتحقق من النسخ.
- `design-reference`: المعاينة المعتمدة كمرجع تصميم فقط؛ التطبيق لا يستخدم WebView أو HTML لتشغيل واجهته.

## إعدادات البناء المثبتة

AGP 8.7.3، Gradle 8.9، Kotlin/Compose compiler 2.0.21، Compose BOM 2024.10.01، Activity 1.9.3، Lifecycle 2.8.7، compile/target SDK 35، build tools 35.0.0، min SDK 26. إصدارات مثبتة لهذا الاختبار، وليست ادعاء بأنها الأحدث.

المرجع الرسمي لتوافق AGP/Gradle/JDK: https://developer.android.com/build/releases/agp-8-7-0-release-notes

المرجع الرسمي لإعداد Compose compiler: https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler

الـWrapper مولّد بأداة Gradle الرسمية، مع SHA-256 لتوزيعة Gradle. لا يحتوي الأرشيف إعدادات SDK أو بروكسي خاصة بالبيئة أو بيانات مالية شخصية.

## البناء

يتطلب JDK 17 أو 21 وAndroid SDK 35 مع build-tools 35.0.0. عيّن SDK عبر `ANDROID_HOME` أو أنشئ `local.properties` بمساره المحلي. ثم من جذر المشروع:

```bash
./gradlew :cashbook-core:check :app:assembleDebug :app:assembleDebugAndroidTest :app:lintDebug
```

الناتج: `app/build/outputs/apk/debug/app-debug.apk`.

على Windows، استخدم `gradlew.bat` بدل `./gradlew`.

اختبار واجهة Android المرفق يفترض تثبيت اختبار نظيف؛ ينشئ حسابًا ويدخل مصروفًا ثم يعيد إنشاء Activity. لتشغيله على جهاز/محاكي متصل:

```bash
./gradlew :app:connectedDebugAndroidTest
```

نتائج ما نُفذ فعلًا في `BUILD_STATUS.md`؛ وجود الاختبار أو بناء APK الاختبار لا يعني أنه نُفذ على جهاز.

## الدمج لاحقًا

انقل `cashbook-core` و`cashbook-feature` إلى المضيف، وأضف اعتمادًا من تطبيق ToDo Shift على الوحدة. يبقى `app` هنا غلاف اختبار يمكن الاستغناء عنه. أنشئ ViewModel واحدًا لدى جذر تنقل المضيف واستدعِ `CashBookRoute(vm)` من وجهته المالية. يجب مواءمة إصدارات المضيف، والقفل والتنقل والنسخ والترحيل قبل الدمج. لا تستبدل حسابات الرواتب القديمة مباشرة.

التصميم المعتمد: اختيار الحساب في الرأس، خمس فترات، دفتر الحركة، زرا الإيراد/المصروف، الإجماليات الثلاثة، ونفس ترتيب شاشة الإدخال المصغّرة.

## حدود النسخة

تجريبية وليست إصدار نشر. PDF/Excel وDrive والقفل المالي وإدارة دورة حياة الحسابات ليست مكتملة. الفواتير على Android تحفظ كمراجع مستندات مع إذن قراءة، والنسخ الاحتياطي لا ينقل محتويات الملفات. بيانات هذه النسخة مستقلة، ولا توجد هنا آلية لنقل بياناتها تلقائيًا إلى ToDo Shift.

## إصلاح 0.7

راجع UI_REPAIR_07.md لتغييرات الحركة والإدخال والحسابات، وBUILD_STATUS.md لنتائج التنفيذ الفعلية. الإصدار 3 يستخدم شهادة اختبار 0.6 نفسها وصيغة البيانات نفسها. المحرر شاشة في Activity؛ لا تضف imePadding آخر داخل CashBookRoute عند الدمج، بل وفر viewport مضبوطًا من المضيف كما يفعل app هنا.

اختبار ReferenceLayoutTest مخصص لمحاكي اختبار مؤقت: يعيد إنشاء بيانات تجريبية ويحذف ملفات بيانات القسم على تثبيته. لا تشغله على تثبيت يحتوي بيانات مستخدم. نتائج هذا الاختبار وصوره في verification بعد التنفيذ.

## إعادة ترتيب الحسابات في 0.8

راجع ACCOUNT_ORDER_08.md لسلوك السحب والحفظ، وBUILD_STATUS.md لنتائج اختباري Android المنفصلين قبل وبعد إعادة تشغيل العملية. نسخة 0.8 تستخدم versionCode=4 والحزمة والتوقيع نفسيهما. مسميات أزرار الحسابات لم تتغير في هذه الجولة.

## تخصيص 0.9

قوالب أزواج مسميات قابلة للتعديل لكل حساب، وافتراضي للحسابات الجديدة، و120 إيموجي أو رمز مخصص. لا أنواع حسابات مفروضة. راجع CUSTOMIZATION_09.md للتوافق وصيغة البيانات 4، وCUSTOMIZATION_QA_09.md لنتائج الاختبار.
