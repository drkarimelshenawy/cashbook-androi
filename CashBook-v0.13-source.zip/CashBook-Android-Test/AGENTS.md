# Cash Book contribution rules

- Keep this a standalone test host plus mergeable cashbook-core/cashbook-feature modules. Do not edit ToDo Shift as part of a Cash Book change without an explicit integration task.
- Every new user-facing string belongs in both values/strings.xml (English) and values-ar/strings.xml (Arabic), including notifications and errors. Keep format placeholders aligned. Account names, notes and personal labels are user data, not translation targets.
- Keep physical layout and button order LTR in both languages. Localize text direction, text alignment and dates independently. Never mirror button positions on a language change.
- Use whole currency units for new user-entered amounts, number-only keyboards, and a signed numeric keyboard only for opening balances. Internal storage remains exact minor units. Do not round, truncate, reclassify or eagerly rewrite legacy fractional data.
- Payment linking is optional and OFF for new payments. A linked payment changes the financial account and debt atomically; an unlinked payment changes only the debt. Keep targeted-installment and advance-credit metadata through edits, deletion/undo, backups and restore.
- Preserve the repayment progress bar and the independent Installments/Payments tabs. Keep due/payment rows compact. Row actions belong in details dialogs.
- Keep one financial writer, the shared AtomicFile I/O lock, and latest-snapshot serialized reminder planning. Read failures must never become an empty financial snapshot. A notification failure must not be reported as a failed financial save.
- Run tools/check_localization.py and the relevant core checks. Build and lint the Android host. For visual/keyboard/language changes, verify Arabic and English on Android with a small-screen case; report exactly what was tested.
- Keep the test signing key/package continuity. The Android reminder receiver is enabled only in the temporary app host; use DebtReminders.Host for the future unified ToDo Shift notification integration.
